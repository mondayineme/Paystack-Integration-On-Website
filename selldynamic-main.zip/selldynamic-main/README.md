# selldynamic
This code perfectly sell products and apply their prices to each product name effectively
This application was created in PHP and cURL.
After downloading, place the folder in your server or local root directory like htdocs if you are developing offline. Run the application in your browser. Be sure that you have network connections

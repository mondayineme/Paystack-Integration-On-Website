<?php
$products = array(
     "1" => array(
         "id" => 1,
         "title" => "Paystack Integration E-book",
         "price" => "700",
         "description" => "This E-book is built using PHP and cURL for seamless integration of Paystack.",
         "pix" => '<img src="images/ebook1.jpg" width="100%" height="300px" alt="E-book one">'
     ),

     "2" => array(
         "id" => 2,
         "title" => "FlutterWave Integration E-book",
         "price" => "800",
         "description" => "This E-book is built using PHP and cURL for seamless integration of FlutterWave.",
         "pix" => '<img src="images/ebook2.gif" width="100%" height="300px" alt="E-book two">'
     ),
     "3" => array(
         "id" => 3,
         "title" => "PayPal Integration E-book",
         "price" => "1000",
         "description" => "This E-book is built using PHP and cURL for seamless integration of PayPal.",
         "pix" => '<img src="images/ebook3.jpg" width="100%" height="300px" alt="E-book 3">'
     )
);
?>